package Model;

public interface MostrarDados {
    void mostrarDados();
}
